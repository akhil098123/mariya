import json
import time
import requests
import logging
from io import BytesIO
from flask import Flask, render_template, request, send_file

app = Flask(__name__)

# Setup logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Mapping of district names to district codes
DISTRICT_CODES = {
    "Thiruvananthapuram": "503001",
    "Kollam": "503002",
    "Pathanamthitta": "503003",
    "Alappuzha": "503004",
    "Kottayam": "503005",
    "Idukki": "503006",
    "Ernakulam": "503007",
    "Thrissur": "503008",
    "Palakkad": "503009",
    "Malappuram": "503010",
    "Kozhikode": "503011",
    "Wayanad": "503012",
    "Kannur": "503013",
    "Kasaragod": "503014",
}

LB_TYPE_IDS = {
    'corporation': 4,
    'municipality': 3,
    'panchayat': 5,
    'all': [4, 3, 5]  # Treat 'all' as all types of local bodies
}

# Load the local bodies data from a JSON file
def load_local_bodies_data():
    try:
        with open('local_bodies.json', 'r') as json_file:
            return json.load(json_file)
    except Exception as e:
        logger.error(f"Error loading local bodies data: {e}")
        return {}

# Function to fetch local bodies from the loaded data
def fetch_local_bodies(district_code, lb_type_id):
    local_bodies_data = load_local_bodies_data()
    
    lb_type_mapping = {4: "corporation", 3: "municipality", 5: "panchayat"}
    lb_type = lb_type_mapping.get(lb_type_id)

    # Get the district name using the district code
    district_name = next((name for name, code in DISTRICT_CODES.items() if code == district_code), None)

    if district_name and lb_type:
        return local_bodies_data.get(district_name, {}).get(lb_type, [])
    return []

# Function to fetch birth information based on office code
def fetch_birth_info(lb_office_code, district_id, dob, mother_name, lb_type_id, gender):
    url = "https://api.ksmart.lsgkerala.gov.in/birth-services/cr/birth-search/advanced?page=0&size=10&sort=childDetails.dateOfBirth"
    headers = {
        'Host': 'api.ksmart.lsgkerala.gov.in',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Content-Type': 'application/json',
        'X-STATE-CODE': 'kl',
        'X-LANGUAGE': 'en',
        'Origin': 'https://ksmart.lsgkerala.gov.in',
        'Connection': 'keep-alive',
        'Referer': 'https://ksmart.lsgkerala.gov.in/',
    }

    payload = {
        "districtId": district_id,
        "lbOfficeCode": lb_office_code,
        "lbTypeId": lb_type_id,
        "dateOfBirth": dob,
        "gender": gender,  # Use gender from the form input
        "motherName": mother_name
    }

    logger.info(f"Sending request with payload: {json.dumps(payload, indent=2)}")

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        response.raise_for_status()  # Raise an exception for bad responses (4xx, 5xx)
        if response.status_code == 200:
            birth_info = response.json()
            logger.info(f"Received birth information: {json.dumps(birth_info, indent=2)}")
            return birth_info.get("content", [])
    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching birth information: {e}")
    return []

# Route to download the birth certificate as a PDF
@app.route('/download_certificate/<application_number>', methods=['GET'])
def download_certificate(application_number):
    url = f"https://api.ksmart.lsgkerala.gov.in/birth-services/cr/download/certificate-by-application-number/{application_number}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an error for invalid responses
        
        if response.headers['Content-Type'] == 'application/pdf':
            return send_file(BytesIO(response.content), as_attachment=True, download_name=f"{application_number}_certificate.pdf", mimetype='application/pdf')
        else:
            return "Certificate not available", 404
    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching certificate: {e}")
        return "Failed to download certificate", 500

@app.route('/', methods=['GET', 'POST'])
def index():
    birth_info = None
    loading = False
    error_message = None

    if request.method == 'POST':
        district_code = request.form['district_id']
        dob = request.form['dob']
        mother_name = request.form['mother_name']
        lb_type = request.form['lb_type']
        gender = request.form['gender']

        logger.debug(f"Received form inputs: District Code = {district_code}, Date of Birth = {dob}, Mother's Name = {mother_name}, Local Body Type = {lb_type}, Gender = {gender}")

        formatted_dob = dob
        if not formatted_dob:
            error_message = "Invalid date format. Please use yyyy-mm-dd"
            return render_template('index.html', birth_info=None, loading=False, error_message=error_message)

        district_name = next((name for name, code in DISTRICT_CODES.items() if code == district_code), None)
        if not district_name:
            error_message = "Invalid district code"
            return render_template('index.html', birth_info=None, loading=False, error_message=error_message)

        lb_type_ids_to_search = LB_TYPE_IDS.get(lb_type.lower(), [4, 3, 5])
        if isinstance(lb_type_ids_to_search, int):
            lb_type_ids_to_search = [lb_type_ids_to_search]

        loading = True
        all_birth_info = []

        for lb_type_id in lb_type_ids_to_search:
            local_body_codes = fetch_local_bodies(district_code, lb_type_id)
            time.sleep(1)

            if not local_body_codes:
                continue

            for lb_office_code in local_body_codes:
                birth_info = fetch_birth_info(lb_office_code, district_code, formatted_dob, mother_name, lb_type_id, gender)
                if birth_info:
                    all_birth_info.extend(birth_info)

        loading = False

        if all_birth_info:
            for record in all_birth_info:
                record['certificate_download_url'] = f"/download_certificate/{record['applicationNumber']}"

            birth_info = all_birth_info
        else:
            error_message = "No birth information found for the given search criteria."

    return render_template('index.html', birth_info=birth_info, loading=loading, error_message=error_message)

if __name__ == '__main__':
    app.run(debug=True)
